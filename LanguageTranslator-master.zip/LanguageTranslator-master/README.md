# LanguageTranslator
Before getting started Pip install the googletrans library
You can translate words and sentences from various specified languages to over 40 different languages.
I prefer you to run it on a cmd that is to run the saved file without opening it in an editor as the command line interface will display all 
the unicode characters which sometimes editors such as IDLE fail to display

Happy Programming !!!!!!!!!!!
